package com.example.SpringSecurityJWT.security.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.SpringSecurityJWT.models.Account;
import com.example.SpringSecurityJWT.models.AccountReq;
import com.example.SpringSecurityJWT.models.Transaction;
import com.example.SpringSecurityJWT.models.User;
import com.example.SpringSecurityJWT.payload.request.LoginRequest;
import com.example.SpringSecurityJWT.repository.AccountRepository;
import com.example.SpringSecurityJWT.repository.AccountReqrepository;
import com.example.SpringSecurityJWT.repository.BankRepository;
import com.example.SpringSecurityJWT.repository.BranchRepository;
import com.example.SpringSecurityJWT.repository.TransactionRepository;
import com.example.SpringSecurityJWT.repository.UserRepository;

@Service
public class BankService {
		@Autowired
		AccountRepository accountrepo;
		@Autowired
		BankRepository bankrepo;
		@Autowired
		BranchRepository branchrepo;
		@Autowired
		TransactionRepository transactionrepo;
		@Autowired
		UserRepository userrepo;
		@Autowired
		AccountReqrepository accreqrepo;
		
		
		
//		public void setAccount (int account_id) {
//			loggedAccount=accountrepo.getById(account_id);
//		}
		public Account transfer(Transaction trans) {
			return  accountrepo.getById(trans.getTo_account_id());
			
		}
		public void reducebal(int amount,User loggedUser) {
			Account loggedAccount = loggedUser.getAccount();
			loggedAccount.setBalance(loggedAccount.getBalance()-amount);
			accountrepo.saveAndFlush(loggedAccount);
		}
		public void increasebal(Account to,int amount) {
			to.setBalance(to.getBalance()+amount);
			accountrepo.saveAndFlush(to);
		}
		public void addtransaction(Transaction trans) {
			transactionrepo.save(trans);
		}
		public List<Transaction> getTransaction(){
			return transactionrepo.findAll();
		}
		public void signup(User user) {
			userrepo.save(user);
		}
		public List<User> Login(LoginRequest user) {
			return userrepo.Login(user.getUsername());
		}
		public void addAccountRequest(AccountReq req) {
			accreqrepo.save(req);
		}
		public List<AccountReq> getaccRequest(){
			return accreqrepo.findAll();
		}
		public void deleteaccReq(int id) {
			accreqrepo.deleteById(id);
		}
		public AccountReq getAccountReq(int id) {
			return accreqrepo.getById(id);
		}
		public void savetoAcc(Account a) {
			accountrepo.save(a);
		}
		public int getBal(int id) {
			Optional<Account> optionalAccount = accountrepo.findById(id);
			if (optionalAccount.isPresent()) {
		        Account account = optionalAccount.get();
		        return account.getBalance();
		    } 
			else {
				return -1;
			}
		}
		
}
