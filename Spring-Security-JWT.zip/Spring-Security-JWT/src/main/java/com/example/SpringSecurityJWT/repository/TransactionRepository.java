package com.example.SpringSecurityJWT.repository;

//import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
//import org.springframework.data.jpa.repository.Modifying;
//import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

//import com.example.SpringSecurityJWT.models.Account;
import com.example.SpringSecurityJWT.models.Transaction;

//import jakarta.transaction.Transactional;

@Repository
public interface TransactionRepository extends JpaRepository<Transaction, Integer>{

//	@Modifying
//	@Query(value="Select * from Transaction t where t.account_id= ?1 ",nativeQuery = true)
//	@Transactional
//	public List<Transaction> getTransaction(Integer a);
}
