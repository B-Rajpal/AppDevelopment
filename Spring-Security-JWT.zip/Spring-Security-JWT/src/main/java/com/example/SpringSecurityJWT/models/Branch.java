package com.example.SpringSecurityJWT.models;

import java.util.List;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name="branch")
public class Branch {
	@Id
	@GeneratedValue
	private int branch_id;
	private String branch_name;
	@ManyToOne
	@JoinColumn(name = "bank_id")
	private Bank bank;
	@OneToMany(mappedBy = "branch")
	private List<Account> account;
	
	
	public Branch() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getBranch_id() {
		return branch_id;
	}
	public void setBranch_id(int branch_id) {
		this.branch_id = branch_id;
	}
	public String getBranch_name() {
		return branch_name;
	}
	public void setBranch_name(String branch_name) {
		this.branch_name = branch_name;
	}
	
}
